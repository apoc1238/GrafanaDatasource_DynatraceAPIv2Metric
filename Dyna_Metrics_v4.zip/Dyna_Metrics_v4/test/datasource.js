'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _data = require('@grafana/data');

var _runtime = require('@grafana/runtime');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var DataSource = function () {
  function DataSource(instanceSettings, $q, backendSrv, templateSrv) {
    _classCallCheck(this, DataSource);

    this.baseUrl = instanceSettings.url;
    this.token = instanceSettings.jsonData.token;
    this.backendSrv = backendSrv;
    this.templateSrv = templateSrv;
    this.getBackendSrv = _runtime.getBackendSrv;
    this.metrics = [];
    this.metricsCache = null;
  }

  _createClass(DataSource, [{
    key: 'fetchAllMetrics',
    value: async function fetchAllMetrics() {
      var pageKey = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

      if (this.metricsCache && !pageKey) {
        return this.metricsCache;
      }
      var metrics = [];
      try {
        var url = '/api/v2/metrics';
        if (pageKey) {
          url += '?nextPageKey=' + pageKey;
        }
        var response = await this.request(url);
        if (response.status === 200 && response.data && response.data.metrics) {
          metrics = response.data.metrics.map(function (metric) {
            return {
              text: metric.displayName,
              value: metric.metricId
            };
          });
          if (response.data.nextPageKey) {
            // Fetch the next page of results
            var nextPageMetrics = await this.fetchAllMetrics(response.data.nextPageKey);
            metrics = metrics.concat(nextPageMetrics);
          }
        }
      } catch (err) {
        console.error('Failed to fetch metrics:', err);
      }
      if (!pageKey) {
        this.metricsCache = metrics;
      }
      return metrics;
    }
  }, {
    key: 'query',
    value: async function query(options) {
      var _this = this;

      try {
        if (options.targets[0].customQuery && options.targets[0].customQuery.length) {
          var queryUrl = '/api/v2/metrics/query?metricSelector=' + options.targets[0].customQuery;
          console.log('Making request to:', queryUrl);
          var response = await this.request(queryUrl);
          console.log('Response:', response);
          var metricData = response.data.result[0].data;
          var frames = metricData.map(function (metric) {
            var timestamps = metric.timestamps,
                values = metric.values,
                dimensions = metric.dimensions;

            var repeatedDimensions = Array(timestamps.length).fill(dimensions[0]);
            return new _data.MutableDataFrame({
              refId: options.targets[0].refId,
              name: dimensions[0],
              fields: [{ name: 'Time', type: _data.FieldType.time, values: timestamps }, { name: 'Value', type: _data.FieldType.number, values: values }, { name: 'Dimension', type: _data.FieldType.string, values: repeatedDimensions }]
            });
          });
          return { data: frames };
        }
        console.log('Query options:', options);
        var promises = options.targets.filter(function (target) {
          return target.metric && target.metric.length > 0;
        }).map(async function (target) {
          var queryUrl = '/api/v2/metrics/query?metricSelector=' + target.metric + ':splitBy()&from=' + options.range.from.toISOString() + '&to=' + options.range.to.toISOString();
          if (target.splitBy) {
            queryUrl = '/api/v2/metrics/query?metricSelector=' + target.metric + ':splitBy("' + target.splitBy + '")&from=' + options.range.from.toISOString() + '&to=' + options.range.to.toISOString();
            // queryUrl += `&splitBy=${target.splitBy}`;
          }
          if (target.filterCriteria && target.filterValue) {
            var filterCriteria = encodeURIComponent(target.filterCriteria);
            var filterValue = encodeURIComponent(target.filterValue);
            queryUrl += '&entitySelector=' + filterCriteria + ':' + filterValue;
          }
          console.log('Making request to:', queryUrl);
          var response = await _this.request(queryUrl);
          console.log('Response:', response);
          var metricData = response.data.result[0].data;
          var frames = metricData.map(function (metric) {
            var timestamps = metric.timestamps,
                values = metric.values,
                dimensions = metric.dimensions;

            var repeatedDimensions = Array(timestamps.length).fill(dimensions[0]);
            return new _data.MutableDataFrame({
              refId: target.refId,
              name: dimensions[0],
              fields: [{ name: 'Time', type: _data.FieldType.time, values: timestamps }, { name: 'Value', type: _data.FieldType.number, values: values }, { name: 'Dimension', type: _data.FieldType.string, values: repeatedDimensions }]
            });
          });
          return frames;
        });
        return Promise.all(promises).then(function (data) {
          return { data: data.flat() };
        });
      } catch (error) {
        console.error('Error during query:', error);
        throw error;
      }
    }
  }, {
    key: 'metricFindQuery',
    value: async function metricFindQuery(query) {
      try {
        var response = await this.request('/api/v2/metrics?text=' + query);
        console.log('Response:', response);
        if (response.status !== 200 || !response.data || !response.data.metrics) {
          return [];
        }
        return response.data.metrics.map(function (metric) {
          return {
            text: metric.displayName,
            value: metric.metricId
          };
        });
      } catch (err) {
        console.error('Failed to fetch metrics:', err);
        return [];
      }
    }
  }, {
    key: 'fetchMetricDimensions',
    value: async function fetchMetricDimensions(metricId) {
      var url = '/api/v2/metrics/' + metricId;
      var response = await this.request(url);
      if (response.status !== 200 || !response.data || !response.data.dimensionDefinitions) {
        return [];
      }
      return response.data.dimensionDefinitions.map(function (def) {
        return {
          text: def.displayName,
          value: def.key
        };
      });
    }
  }, {
    key: 'request',
    value: async function request(url, params) {
      try {
        var fullUrl = '' + this.baseUrl + url + (params ? '&' + params : '');
        console.log('Making request:', fullUrl);
        var response = await (0, _runtime.getBackendSrv)().fetch({
          url: fullUrl,
          headers: {
            Authorization: 'Api-Token ' + this.token
          }
        }).toPromise();
        console.log('Received response:', response);
        if (response.ok) {
          return response;
        }
        console.error('Failed to fetch data. Status: ' + response.status);
        throw new Error('Failed to fetch data. Status: ' + response.status);
      } catch (error) {
        console.error('Error making request:', error);
        throw error; // re-throw the error to be caught and handled elsewhere
      }
    }
  }, {
    key: 'testDatasource',
    value: async function testDatasource() {
      var defaultErrorMessage = 'Cannot connect to APIs';

      try {
        var response = await this.request('/api/v2/metrics');
        if (response.status === 200) {
          return {
            status: 'success',
            message: 'Successoooo'
          };
        }
        return {
          status: 'error',
          message: response.statusText || defaultErrorMessage
        };
      } catch (err) {
        var message = '';
        if (typeof err === 'string') {
          message = err;
        } else if ((0, _runtime.isFetchError)(err)) {
          message = 'Fetch error: ' + (err.statusText || defaultErrorMessage);
          if (err.data && err.data.error && err.data.error.code) {
            message += ': ' + err.data.error.code + '. ' + err.data.error.message;
          }
        }
        return {
          status: 'error',
          message: message
        };
      }
    }
  }]);

  return DataSource;
}();

exports.default = DataSource;
//# sourceMappingURL=datasource.js.map
