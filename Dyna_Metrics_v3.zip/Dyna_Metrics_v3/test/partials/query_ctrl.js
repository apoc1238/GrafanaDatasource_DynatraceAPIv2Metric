'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var DynatraceDatasourceQueryCtrl = function () {
  function DynatraceDatasourceQueryCtrl($scope, $injector) {
    _classCallCheck(this, DynatraceDatasourceQueryCtrl);

    this.scope = $scope;
    this.injector = $injector;
    this.target.queryText = this.target.queryText || '';
  }

  _createClass(DynatraceDatasourceQueryCtrl, [{
    key: 'getMetrics',
    value: function getMetrics(query) {
      return this.datasource.metricFindQuery(query);
    }
  }, {
    key: 'onChange',
    value: function onChange() {
      this.panelCtrl.refresh();
    }
  }]);

  return DynatraceDatasourceQueryCtrl;
}();

DynatraceDatasourceQueryCtrl.templateUrl = 'partials/query.editor.html';

exports.DynatraceDatasourceQueryCtrl = DynatraceDatasourceQueryCtrl;
//# sourceMappingURL=query_ctrl.js.map
